package praticaaedrand;

import java.lang.Math;

public class PraticaAEDrand {

    public static void main(String[] args) {
        PRNG teste = new PRNG();
        int t[] = teste.LCM(100000, 5000);
//        int t[] = teste.LCM(256,500);
//        teste.print(t);
//        System.out.println(teste.periodo(t));
//        teste.porcentPeriodo(t);
        

        double v[] = new double[teste.periodo(t)]; //vetor a ser prenchido usando valores do math.random
        preencheRand(v);
        
//        teste.printXY(t);//pares ordenados usando os valores do meu PRNG
        
//        teste.printXY2(v); //pares ordenados usando os valores do Math.random();
        
        comparaTempo();
    }

    static public void comparaTempo() {
        PRNG teste = new PRNG();
        long tempo = System.nanoTime();
        int t[] = teste.LCM(100000, 5000);
        tempo = System.nanoTime() - tempo;
        System.out.println("Tempo para o PRNG implementado preencher um vetor de 5 mil posicoes: " + tempo + " Nanossegundos");

        tempo = System.nanoTime();
        double t2[] = new double[5000];
        for (int i = 0; i < t2.length; i++) {
            t2[i] = Math.random();
        }
        tempo = System.nanoTime() - tempo;
        System.out.println("Tempo para o preencher um vetor de 5 mil posicoes com Math.random(): " + tempo + " Nanossegundos");
    }

    static public void preencheRand(double v[]) {
        for (int i = 0; i < v.length; i++) {
            v[i] = (double) (Math.round(Math.random() * 10000.0) / 10000.0);
        }
    }
}