/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lista7;

import java.util.Random;

/**
 *
 * @author junio
 */
public class Lista7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        bTree1kB();
        bTree256B();
        
    }
    static void bTree1kB() {
        System.out.println("\n------------------Arvore B com arquivos de 1kb------------------\n");
        
        ArvoreB t1 = new ArvoreB(4,1000);
        ArvoreB t2 = new ArvoreB(4,100000);
        ArvoreB t3 = new ArvoreB(4,10000000);
        
        preencheArvore(t1);
        preencheArvore(t2);
        preencheArvore(t3);
        
        System.out.println("");
        
        remove5pct(t1);
        remove5pct(t2);
        remove5pct(t3);
        
        
           
    }
    
    static void bTree256B() {
        System.out.println("\n------------------Arvore B com arquivos de 256B------------------\n");
        
        ArvoreB t1 = new ArvoreB(8,1000);
        ArvoreB t2 = new ArvoreB(8,100000);
        ArvoreB t3 = new ArvoreB(8,10000000);
        
        preencheArvore(t1);
        preencheArvore(t2);
        preencheArvore(t3);
        
        System.out.println("");
        
        remove5pct(t1);
        remove5pct(t2);
        remove5pct(t3);
        
    }
    
    static void preencheArvore(ArvoreB t) {
        PRNG rand = new PRNG();
        long vetRand[] = rand.LCM(1073741824, 10000000);

        long time = System.currentTimeMillis();
        for (int i = 0; i < t.qtdElementos; i++) {
            t.insere((int) vetRand[i]);
        }
        time = System.currentTimeMillis()- time;
        System.out.println("Tempo de insercão de " + t.qtdElementos + " Arquivos na B de m = " + t.m + ": " + time + " Milissegundos");
    }
    
    static void remove5pct(ArvoreB t) {
        Random rnd = new Random();
        
        int cont = 0;
        PRNG rand = new PRNG();
        long v[] = rand.LCM(1073741824, t.qtdElementos);
        int i = rnd.nextInt(v.length);
        long time = System.nanoTime();
        while(cont < t.qtdElementos * 0.05){
            if(i >= v.length-1){
                i=0;
            }
            t.retira((int)v[i]);
            cont++;
            i++;
        }
        time = System.nanoTime() - time;

        System.out.println("Tempo para remover 5% dos elementos da arvore B de m = " + t.m + ", e " + t.qtdElementos + " Elementos: " + time + " Nanossegundos");

    } //quando os valores inseridos na arvore foram gerados pelo meu PRNG
}
