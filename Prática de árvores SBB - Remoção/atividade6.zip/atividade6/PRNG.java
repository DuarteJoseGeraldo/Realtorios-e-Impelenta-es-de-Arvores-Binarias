package atividade6;


public class PRNG {

    public long[] LCM(long modulo, long numOfRands) {
        long aux[] = new long[(int)numOfRands];
        int     a =  843314861, //multiplicador
                b = 453816693; //icremento
        MetodoCongruencialLinear(0, modulo, a, b, aux, numOfRands);
        return aux;
    }

    private void MetodoCongruencialLinear(int base, long m, int a, int b, long[] randomNums, long noOfRandomNums) {

        // primeira casa do vetor recebe a semente
        randomNums[0] = base;

        for (long i = 1; i < noOfRandomNums; i++) {
            
            randomNums[(int)i] = ((randomNums[(int)i - 1] * a) + b) % m;
        }
    }

    public void print(int v[]) { // Imprime os indices do vetor na esquerda e os valores na direita
        for (int i = 0; i < v.length; i++) {
            System.out.println(i + "\t" + v[i]);
        }
    }

    public int periodo(int v[]) { //encontra o periodo
        for (int i = 0; i < v.length; i++) {
            if (v[i] == 0 && i != 0) {
                return i - 1;
            }
        }
        return 0;
    }

    public void porcentPeriodo(int v[]) { //imprime o vetor de acordo com cada porcentagem do periodo solicitada
        int p = periodo(v);
        int p2 = (int) (p * 0.05);
        int p3 = (int) (p * 0.1);
        int p4 = (int) (p * 0.25);
        int p5 = (int) (p * 0.50);
        int p6 = (int) (p * 0.75);

        System.out.println("Periodo = " + p);
        System.out.println("5% = " + p2 + " Valores\n10% = " + p3 + " Valores\n25% = " + p4 + " Valores\n50% = " + p5 + " Valores\n75% = " + p6 + " Valores");

        System.out.println("Indice\t\t" + "5%\t\t" + "10%\t\t" + "25%\t\t" + "50%\t\t" + "75%\t\t");

        for (int i = 0; i < p; i++) {
            if (i < p2) {
                System.out.println((i + 1) + "\t\t" + v[i] + "\t\t" + v[i] + "\t\t" + v[i] + "\t\t" + v[i] + "\t\t" + v[i]);
            }

            if (i >= p2 && i < p3) {
                System.out.println((i + 1) + "\t\t" + " " + "\t\t" + v[i] + "\t\t" + v[i] + "\t\t" + v[i] + "\t\t" + v[i]);
            }

            if (i >= p3 && i < p4) {
                System.out.println((i + 1) + "\t\t" + " " + "\t\t" + " " + "\t\t" + v[i] + "\t\t" + v[i] + "\t\t" + v[i]);
            }

            if (i >= p4 && i < p5) {
                System.out.println((i + 1) + "\t\t" + " " + "\t\t" + " " + "\t\t" + " " + "\t\t" + v[i] + "\t\t" + v[i]);
            }

            if (i >= p5 && i < p6) {
                System.out.println((i + 1) + "\t\t" + " " + "\t\t" + " " + "\t\t" + " " + "\t\t" + " " + "\t\t" + v[i]);
            }

        }
    }

    public void printXY(int v[]){ //gera coordenadas x e y de acordo com o periodo, x = indices pares / y = indices impares
        int p = periodo(v);

        int p2 = (int) (p * 0.05);
        int p3 = (int) (p * 0.1);
        int p4 = (int) (p * 0.25);
        int p5 = (int) (p * 0.50);
        int p6 = (int) (p * 0.75);

        System.out.println("Periodo = " + p);
        System.out.println("5% = " + p2 + " Valores\n10% = " + p3 + " Valores\n25% = " + p4 + " Valores\n50% = " + p5 + " Valores\n75% = " + p6 + " Valores\n");

        System.out.println("X\t" + "Y\t");
        for (int i = 0; i < p; i++) {
            if (i % 2 == 0) {
                System.out.print(v[i]);
            } else {
                System.out.println("\t" + v[i]);
            }
        }
    }
    
    public void printXY2(double v[]){ //gera coordenadas x e y para o math.random
        System.out.println("\nX\t" + "Y\t");
        for (int i = 0; i < v.length; i++) {
            if (i % 2 == 0) {
                System.out.print(v[i]);
            } else {
                System.out.println("\t" + v[i]);
            }
        }
    }
    
    
}
