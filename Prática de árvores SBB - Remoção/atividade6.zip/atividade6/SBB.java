package atividade6;

public class SBB {

    public static final byte Horizontal = 0;
    public static final byte Vertical = 1;
    public No raiz;
    public boolean prop;
    public static int count = 0;
    public int qtdNos; //Apenas para uso no trabalho, pra fazer os prints no console

    private static class No {

        int reg;
        No esq, dir;
        byte incE, incD;

        No(int reg) {
            this.reg = reg;
            esq = null;
            dir = null;
            incE = Vertical;
            incD = Vertical;
        }
    }

    public SBB() {
        raiz = null;
        prop = true;
    }

    public SBB(int tam) {
        raiz = null;
        prop = true;
        qtdNos = tam;
    }

    // Se o No "ap" e seu filho e neto estão no mesmo nível
    // há duas ligações horizontais seguidas e
    // as ligações do filho se tornam verticais e ele se torna pai dos demais - transformação
    // transformação esquerda-esquerda
    private No ee(No ap) {
        No ap1 = ap.esq;
        ap.esq = ap1.dir;
        ap1.dir = ap;
        ap1.incE = Vertical;
        ap.incE = Vertical;
        ap = ap1;
        return ap;
    }

    // transformação esquerda-direita
    private No ed(No ap) {
        No ap1 = ap.esq;
        No ap2 = ap1.dir;
        ap1.incD = Vertical;
        ap.incE = Vertical;
        ap1.dir = ap2.esq;
        ap2.esq = ap1;
        ap.esq = ap2.dir;
        ap2.dir = ap;
        ap = ap2;
        return ap;
    }

    // transformação direira-direita
    private No dd(No ap) {
        No ap1 = ap.dir;
        ap.dir = ap1.esq;
        ap1.esq = ap;
        ap1.incD = Vertical;
        ap.incD = Vertical;
        ap = ap1;
        return ap;
    }

    // transformação direita-esquerda
    private No de(No ap) {
        No ap1 = ap.dir;
        No ap2 = ap1.esq;
        ap1.incE = Vertical;
        ap.incD = Vertical;
        ap1.esq = ap2.dir;
        ap2.dir = ap1;
        ap.dir = ap2.esq;
        ap2.esq = ap;
        ap = ap2;
        return ap;
    }

    public No insere(int reg) {
        return insere(reg, null, raiz, false);
    }

    private No insere(int reg, No pai, No filho, boolean filhoEsq) {
        if (filho == null) {                            // se o nó corrente estiver vazio
            filho = new No(reg);                        // insere o registrador nele
            if (pai != null) // se o nó antecessor não for nulo
            {
                if (filhoEsq) {
                    pai.incE = Horizontal;    // reduz um nivel no lado da inserção - Vertical -> Horizontal
                } else {
                    pai.incD = Horizontal;
                }
            }
            prop = false;   // considera desbalancento
        } else if (reg < filho.reg) {             // se o registro for maior que o nó corrente
            filho.esq = insere(reg, filho, filho.esq, true); // tenta inserir na sub-árvore esquerda
            if (!prop) {    // se a propriedade não é atendida - nós filho, neto e tataraneto no mesmo nível
                if (filho.incE == Horizontal) { // se o neto está no mesmo nivel do filho
                    if (filho.esq.incE == Horizontal) { // verifica o sentido do crescimento e efetua uma transformação
                        filho = ee(filho);
                        if (pai != null) {
                            if (filhoEsq) {
                                pai.incE = Horizontal;
                            } else {
                                pai.incD = Horizontal;
                            }
                        }
                    } else if (filho.esq.incD == Horizontal) {
                        filho = ed(filho);
                        if (pai != null) {
                            if (filhoEsq) {
                                pai.incE = Horizontal;
                            } else {
                                pai.incD = Horizontal;
                            }
                        }
                    }
                } else {
                    prop = true; // caso contrário, a propriedade já está atendida
                }
            }
        } else if (reg > filho.reg) {
            filho.dir = insere(reg, filho, filho.dir, false);
            if (!prop) {
                if (filho.incD == Horizontal) {
                    if (filho.dir.incD == Horizontal) {
                        filho = dd(filho);
                        if (pai != null) {
                            if (filhoEsq) {
                                pai.incE = Horizontal;
                            } else {
                                pai.incD = Horizontal;
                            }
                        }
                    } else if (filho.dir.incE == Horizontal) {
                        filho = de(filho);
                        if (pai != null) {
                            if (filhoEsq) {
                                pai.incE = Horizontal;
                            } else {
                                pai.incD = Horizontal;
                            }
                        }
                    }
                } else {
                    prop = true;
                }
            }
        } else {
            //System.out.println ("Erro: Registro ja existente"); 
            prop = true;  // não altera a árvore
        }

        raiz = filho;
        return filho;
    }

    public int buscar(int reg) {
        return buscar(reg, raiz);
    }

    private int buscar(int reg, No p) {
        if (p == null) {
            return -999999;
        } else if (reg < p.reg) {
            return buscar(reg, p.esq);
        } else if (reg > p.reg) {
            return buscar(reg, p.dir);
        } else {
            return p.reg;
        }
    }

    private No esqCurto(No ap) {
        if (ap.incE == Horizontal) {
            ap.incE = Vertical;
            this.prop = true;
        } else if (ap.incD == Horizontal) {
            No ap1 = ap.dir;
            ap.dir = ap1.esq;
            ap1.esq = ap;
            ap = ap1;
            if (ap.esq.dir.incE == Horizontal) {
                ap.esq = this.de(ap.esq);
                ap.incE = Horizontal;
            } else if (ap.esq.dir.incD == Horizontal) {
                ap.esq = this.dd(ap.esq);
                ap.incE = Horizontal;
            }
            this.prop = true;
        } else {
            ap.incD = Horizontal;
            if (ap.dir.incE == Horizontal) {
                ap = this.de(ap);
                this.prop = true;
            } else if (ap.dir.incD == Horizontal) {
                ap = this.dd(ap);
                this.prop = true;
            }
        }
        return ap;
    }

    // @{\it Folha direita retirada => \'arvore curta na altura direita}@
    private No dirCurto(No ap) {
        if (ap.incD == Horizontal) {
            ap.incD = Vertical;
            this.prop = true;
        } else if (ap.incE == Horizontal) {
            No ap1 = ap.esq;
            ap.esq = ap1.dir;
            ap1.dir = ap;
            ap = ap1;
            if (ap.dir.esq.incD == Horizontal) {
                ap.dir = this.ed(ap.dir);
                ap.incD = Horizontal;
            } else if (ap.dir.esq.incE == Horizontal) {
                ap.dir = this.ee(ap.dir);
                ap.incD = Horizontal;
            }
            this.prop = true;
        } else {
            ap.incE = Horizontal;
            if (ap.esq.incD == Horizontal) {
                ap = this.ed(ap);
                this.prop = true;
            } else if (ap.esq.incE == Horizontal) {
                ap = this.ee(ap);
                this.prop = true;
            }
        }
        return ap;
    }

    private No antecessor(No q, No r) {
        if (r.dir != null) {
            r.dir = antecessor(q, r.dir);
            if (!this.prop) {
                r = this.dirCurto(r);
            }
        } else {
            q.reg = r.reg;
            r = r.esq;
            if (r != null) {
                this.prop = true;
            }
        }
        return r;
    }

    private No remover(int reg, No ap) {
        if (ap == null) {
            System.out.println("Erro: Registro nao encontrado");
            this.prop = true;
        } else if (reg < ap.reg) {
            ap.esq = remover(reg, ap.esq);
            if (!this.prop) {
                ap = this.esqCurto(ap);
            }
        } else if (reg > ap.reg) {
            ap.dir = remover(reg, ap.dir);
            if (!this.prop) {
                ap = this.dirCurto(ap);
            }
        } else { // @{\it encontrou o registro}@
            this.prop = false;
            if (ap.dir == null) {
                ap = ap.esq;
                if (ap != null) {
                    this.prop = true;
                }
            } else if (ap.esq == null) {
                ap = ap.dir;
                if (ap != null) {
                    this.prop = true;
                }
            } else {
                ap.esq = antecessor(ap, ap.esq);
                if (!this.prop) {
                    ap = this.esqCurto(ap);
                }
            }
        }
        raiz = ap;
        return ap;
    }

    public No remover(int reg) {
        return remover(reg, this.raiz);
    }
}
