package atividade6;

import java.util.Random;

/**
 *
 * @author junio
 */
public class Atividade6 {

    public static void main(String[] args) {

        testSBBOrd();
        testeSBBRand();
        testeSBBBal();
        testTrie();
        testPatricia();
        
    }

    static void testSBBOrd() {
        System.out.println("\n------------------SBB com valores em Ordem------------------\n");

        SBB tOrd1 = new SBB(1000);
        SBB tOrd2 = new SBB(100000);
        SBB tOrd3 = new SBB(10000000);

        preencheSBBOrd(tOrd1);
        preencheSBBOrd(tOrd2);
        preencheSBBOrd(tOrd3);

        remove5pctOrd(tOrd1);
        remove5pctOrd(tOrd2);
        remove5pctOrd(tOrd3);

    }

    static void testeSBBRand() {
        System.out.println("\n------------------SBB com valores aleatorios------------------\n");

        SBB tRand1 = new SBB(1000);
        SBB tRand2 = new SBB(100000);
        SBB tRand3 = new SBB(10000000);

        preencheSBBRand(tRand1);
        preencheSBBRand(tRand2);
        preencheSBBRand(tRand3);

        remove5pct(tRand1);
        remove5pct(tRand2);
        remove5pct(tRand3);
    }

    static void testeSBBBal() {
        System.out.println("\n------------------SBB com valores Balanceados------------------\n");

        SBB tBal1 = new SBB(1000);
        SBB tBal2 = new SBB(100000);
        SBB tBal3 = new SBB(10000000);

        preencheSBBBal(tBal1);
        preencheSBBBal(tBal2);
        preencheSBBBal(tBal3);

        remove5pctOrd(tBal1);
        remove5pctOrd(tBal2);
        remove5pctOrd(tBal3);
    }

    static void testTrie() {
        System.out.println("\n----------------------TRIE----------------------\n");

        Trie t1 = new Trie(1000);
        Trie t2 = new Trie(100000);
        Trie t3 = new Trie(10000000);

        preencheTrie(t1);
        preencheTrie(t2);
        preencheTrie(t3);

        pesquisaTrie(t1);
        pesquisaTrie(t2);
        pesquisaTrie(t3);
    }

    static void testPatricia() {
        System.out.println("\n--------------------Patricia--------------------\n");

        ArvorePatricia Pat1 = new ArvorePatricia(32, 1000);
        ArvorePatricia Pat2 = new ArvorePatricia(32, 100000);
        ArvorePatricia Pat3 = new ArvorePatricia(32, 10000000);

        preenchePat(Pat1);
        preenchePat(Pat2);
        preenchePat(Pat3);

        pesquisaPat(Pat1);
        pesquisaPat(Pat2);
        pesquisaPat(Pat3);

    }

    static void preencheSBBOrd(SBB t) {
        for (int i = 0; i < t.qtdNos; i++) {
            t.insere(i);
        }
    }

    static void preencheSBBRand(SBB t) {
        PRNG rand = new PRNG();
        long vetRand[] = rand.LCM(1073741824, 10000000);

        for (int i = 0; i < t.qtdNos; i++) {
            t.insere((int) vetRand[i]);
        }
    }

    static void preencheSBBBal(SBB t) {
        long v[] = new long[t.qtdNos];
        preencheVetBal(v);

        for (int i = 0; i < t.qtdNos; i++) {
            t.insere((int) v[i]);
        }

    }

    static void preencheTrie(Trie t) {
        String aux;
        for (Integer i = 0; i < t.qtdNos; i++) {
            aux = RandomString(5);
            t.insere(aux);
            if (i < t.voPesquisarDps.length) {
                t.voPesquisarDps[i] = aux;
            }
        }
    }

    static void preenchePat(ArvorePatricia t) {
        for (int i = 0; i < t.qtdNos; i++) {
            t.insere(i);
        }

    }

    static void preencheVetBal(long v[]) {
        long cont = 0;
        boolean jaFoi[] = new boolean[v.length];

        for (long i = 0; i < (Math.log10(v.length) / Math.log10(2)); i++) { //altura da arvore
            for (long j = 0; j < Math.pow(2, i); j++) { //nivel que ta
                int indice = (int) Math.ceil(((v.length * (2 * j + 1)) / Math.pow(2, i + 1))); //vai ser utilizado para ver se ovalor ja foi inserido e evita erro de inserçao repetida e ognorar outros valores
                if (cont < v.length && indice < v.length && (!jaFoi[indice])) {

                    v[(int) cont] = (long) Math.ceil(((v.length * (2 * j + 1)) / Math.pow(2, i + 1)));
                    jaFoi[(int) Math.ceil(((v.length * (2 * j + 1)) / Math.pow(2, i + 1)))] = true;

                    cont++;
                }
            }
        }
    }

    static void pesquisa30(SBB t) {
        Random rnd = new Random(1000000);
        //salvar o tempo das 30 buscas
        int temp[] = new int[30];
        for (int i = 0; i < temp.length; i++) {
            int aux = (int) System.nanoTime();
            rnd.nextInt();
            aux = (int) System.nanoTime() - aux;
            temp[i] = aux;
        }
        //media do tempo das 30 buscas 
        double med = 0;
        for (int i = 0; i < temp.length; i++) {
            med += temp[i];
        }
        med = med / temp.length;
        //variancia dos tempos
        double auxVar[] = new double[temp.length];
        double var = 0;
        for (int i = 0; i < auxVar.length; i++) {
            auxVar[i] = temp[i] - med;
            auxVar[i] = auxVar[i] * auxVar[i];
            var += auxVar[i];
        }
        //desvio padrao
        double desvio = Math.sqrt(var);

        System.out.println("Tempo de Pesquisa de 30 elementos aleatorios em uma SBB de: " + t.qtdNos + " Elementos");
        System.out.println("Media: " + med + " nanossegundos");
        System.out.println("Desvio Padrao: " + desvio + " nanossegundos\n");
    }

    static void pesquisaPat(ArvorePatricia t) {
        Random rnd = new Random();
        //salvar o tempo das 30 buscas
        int temp[] = new int[(int) (t.qtdNos * 0.01)];
        int j = 0;
        while (j < temp.length) {
            int pesqEsse = rnd.nextInt(t.qtdNos);
            if (t.pesquisa(pesqEsse)) {
                int aux = (int) System.nanoTime();
                t.pesquisa(pesqEsse);
                aux = (int) System.nanoTime() - aux;
                temp[j] = aux;
                j++;
            }
        }
        //media do tempo das buscas 
        double med = 0;
        for (int i = 0; i < temp.length; i++) {
            med += temp[i];
        }
        med = med / temp.length;
        //variancia dos tempos
        double auxVar[] = new double[temp.length];
        double var = 0;
        for (int i = 0; i < auxVar.length; i++) {
            auxVar[i] = temp[i] - med;
            auxVar[i] = auxVar[i] * auxVar[i];
            var += auxVar[i];
        }
        //desvio padrao
        double desvio = Math.sqrt(var);

        System.out.println("Tempo de Pesquisa de " + temp.length + " elementos aleatorios em uma Patricia de: " + t.qtdNos + " Elementos");
        System.out.println("Media: " + med + " nanossegundos");
        System.out.println("Desvio Padrao: " + desvio + " nanossegundos\n");
    }

    static void pesquisaTrie(Trie t) {

        //salvar o tempo das 30 buscas
        int temp[] = new int[(int) (t.qtdNos * 0.01)];
        int j = 0;
        while (j < temp.length) {
            int aux = (int) System.nanoTime();
            if (t.busca(t.voPesquisarDps[j])) {
                aux = (int) System.nanoTime() - aux;
                temp[j] = aux;
                j++;
            }
        }
        //media do tempo das buscas 
        double med = 0;
        for (int i = 0; i < temp.length; i++) {
            med += temp[i];
        }
        med = med / temp.length;
        //variancia dos tempos
        double auxVar[] = new double[temp.length];
        double var = 0;
        for (int i = 0; i < auxVar.length; i++) {
            auxVar[i] = temp[i] - med;
            auxVar[i] = auxVar[i] * auxVar[i];
            var += auxVar[i];
        }
        //desvio padrao
        double desvio = Math.sqrt(var);

        System.out.println("Tempo de Pesquisa de " + temp.length + " elementos aleatorios em uma TRIE de: " + t.qtdNos + " Elementos");
        System.out.println("Media: " + med + " nanossegundos");
        System.out.println("Desvio Padrao: " + desvio + " nanossegundos\n");
    }

    static void remove5pctOrd(SBB t) {
        int v[] = new int[t.qtdNos];//valores para serem retirados
        for (int i = 0; i < v.length; i++) {
            v[i] = i;
        }

        int cont = 0;

        Random rnd = new Random(); //vou pegar uma casa aleatoria do vetor para iniciar assim nao tento remover sempre os mesmos valores
        int i = rnd.nextInt(t.qtdNos);

        long time = System.nanoTime();
        while (cont < t.qtdNos * 0.05) {
            if (i >= v.length - 1) {
                i = 0;
            }
            t.remover(v[i]);
            cont++;
            i++;
        }
        time = System.nanoTime() - time;

        System.out.println("Tempo para remover 5% dos elementos da SBB de " + t.qtdNos + " Elementos: " + time + " Nanossegungos");

    } //uso para quando os valores inseridos na arvore foram gerados em ordem

    static void remove5pct(SBB t) {
        int cont = 0;
        PRNG rand = new PRNG();
        long v[] = rand.LCM(1073741824, t.qtdNos);
        int i = 0;
        long time = System.nanoTime();
        while (cont < t.qtdNos * 0.05) {
            if (i >= v.length - 1) {
                i = 0;
            }
            t.remover((int) v[i]);
            cont++;
            i++;
        }
        time = System.nanoTime() - time;

        System.out.println("Tempo para remover 5% dos elementos da arvore de " + t.qtdNos + " Elementos: " + time + " Nanossegundos");

    } //quando os valores inseridos na arvore foram gerados pelo meu PRNG

    static String RandomString(int i) {
        String Alfabeto;
        StringBuilder builder;

        Alfabeto = "abcdefghijklmnopqrstuvwxyz";

        //create the StringBuffer
        builder = new StringBuilder(i);

        for (int m = 0; m < i; m++) {

            // generate numeric
            int myindex = (int) (Alfabeto.length() * Math.random());

            // add the characters
            builder.append(Alfabeto
                    .charAt(myindex));
        }

        return builder.toString();
    }
}
