package praticaarvorebinaria;

import java.util.Random;

public class PraticaArvoreBinaria {

    public static void main(String[] args) {
        questao1();
        questao2();
        questao3();
    }

    static void questao1() {
        System.out.println("------------------Arvore com valores em Ordem------------------\n");

        Tree tOrd1 = new Tree();
        Tree tOrd2 = new Tree();
        Tree tOrd3 = new Tree();
        Tree tOrd4 = new Tree();
//        Tree tOrd5 = new Tree();

        preencheArvoreOrd(tOrd1, 10);
        preencheArvoreOrd(tOrd2, 1000);
        preencheArvoreOrd(tOrd3, 100000);
        preencheArvoreOrd(tOrd4,10000000);
//        preencheArvoreOrd(tOrd5,1000000000);


        System.out.println("");

        pesquisa30(tOrd1);
        pesquisa30(tOrd2);
        pesquisa30(tOrd3);
        pesquisa30(tOrd4);
//        pesquisa30(tOrd5);

    }

    static void questao2() {
        System.out.println("------------------Arvore com valores fora de Ordem------------------\n");
        PRNG rand = new PRNG();
        //Valores aleatorios

        long vetRand1[] = rand.LCM(1073741824, 10);
        long vetRand2[] = rand.LCM(1073741824, 1000);
        long vetRand3[] = rand.LCM(1073741824, 100000);
        long vetRand4[] = rand.LCM(1073741824, 10000000);
//        long vetRand5[] = rand.LCM(1073741824, 1000000000); //Memoria insufuciente para declarar o vetor de 10^9 posicoes
        Tree tRand1 = new Tree();
        preencheArvoreRand(tRand1, vetRand1);
        Tree tRand2 = new Tree();
        preencheArvoreRand(tRand2, vetRand2);
        Tree tRand3 = new Tree();
        preencheArvoreRand(tRand3, vetRand3);
        Tree tRand4 = new Tree();
        preencheArvoreRand(tRand4, vetRand4);
//        Tree tRand5 = new Tree();
//        preencheArvoreRand(tRand5, vetRand5);

        System.out.println("");

        pesquisa30(tRand1);
        pesquisa30(tRand2);
        pesquisa30(tRand3);
        pesquisa30(tRand4);
//        pesquisa30(tRand5);
    }

    static void questao3() {
        System.out.println("------------------Arvore Balanceada------------------\n");
        //Arvores balanceadas
        long vetBal1[] = new long[10];
        preencheVetBal(vetBal1);
        long vetBal2[] = new long[1000];
        preencheVetBal(vetBal2);
        long vetBal3[] = new long[100000];
        preencheVetBal(vetBal3);
        long vetBal4[] = new long[10000000];
        preencheVetBal(vetBal4);
//        long vetBal5[] = new long[1000000000];
//        
        Tree tBal1 = new Tree();
        preencheArvoreRand(tBal1, vetBal1);
        Tree tBal2 = new Tree();
        preencheArvoreRand(tBal2, vetBal2);
        Tree tBal3 = new Tree();
        preencheArvoreRand(tBal3, vetBal3);
        Tree tBal4 = new Tree();
        preencheArvoreRand(tBal4, vetBal4);
//        Tree tBal5 = new Tree();
//        preencheArvoreRand(tBal5, vetBal5);

        System.out.println("");
        pesquisa30(tBal1);
        pesquisa30(tBal2);
        pesquisa30(tBal3);
        pesquisa30(tBal4);
//        pesquisa30(tBal5);
    }

    static void preencheArvoreOrd(Tree t, long n) {
        long time = System.currentTimeMillis();
        for (long i = 0; i < n; i++) {
            t.inserirOrd(i);
        }
        time = System.currentTimeMillis() - time;
        System.out.println("Tempo de insercão de " + t.getQtdNos() + " Valores ordenados na arvore binaria: " + time + " Milissegundo(os)");
    }

    static void preencheArvoreRand(Tree t, long v[]) {
        long time = System.currentTimeMillis();
        for (long i = 0; i < v.length; i++) {
            t.inserir(v[(int) i]);
        }
        time = System.currentTimeMillis() - time;
        System.out.println("Tempo de insercão de " + v.length + " Valores aleatorios na arvore binaria: " + time + " Milissegundo(os)");
    }

    static void preencheVetBal(long v[]) {
        long cont = 0;
        boolean jaFoi[] = new boolean[v.length];

        for (long i = 0; i < (Math.log10(v.length) / Math.log10(2)); i++) { //altura da arvore
            for (long j = 0; j < Math.pow(2, i); j++) { //nivel que ta
                int indice = (int) Math.ceil(((v.length * (2 * j + 1)) / Math.pow(2, i + 1))); //vai ser utilizado para ver se ovalor ja foi inserido e evita erro de inserçao repetida e ognorar outros valores
                if (cont < v.length && indice < v.length && (!jaFoi[indice])) {

                    v[(int) cont] = (long) Math.ceil(((v.length * (2 * j + 1)) / Math.pow(2, i + 1)));
                    jaFoi[(int) Math.ceil(((v.length * (2 * j + 1)) / Math.pow(2, i + 1)))] = true;

                    cont++;
                }
            }
        }
    }

    static void pesquisa30(Tree t) {
        Random rnd = new Random(1000000000);
        //salvar o tempo das 30 buscas
        int temp[] = new int[30];
        for (int i = 0; i < temp.length; i++) {
            int aux = (int) System.nanoTime();
            t.buscar(rnd.nextInt());
            aux = (int) System.nanoTime() - aux;
            temp[i] = aux;
        }
        //media do tempo das 30 buscas 
        double med = 0;
        for (int i = 0; i < temp.length; i++) {
            med += temp[i];
        }
        med = med / temp.length;
        //variancia dos tempos
        double auxVar[] = new double[temp.length];
        double var = 0;
        for (int i = 0; i < auxVar.length; i++) {
            auxVar[i] = temp[i] - med;
            auxVar[i] = auxVar[i] * auxVar[i];
            var += auxVar[i];
        }
        //desvio padrao
        double desvio = Math.sqrt(var);

        System.out.println("Tempo de Pesquisa de 30 elementos aleatorios em uma arvore de: " + t.getQtdNos() + " Elementos");
        System.out.println("Media: " + med + " nanossegundos");
        System.out.println("Desvio Padrao: " + desvio + " nanossegundos\n");
    }
}
